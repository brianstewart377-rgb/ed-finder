"""Recommended build generation package."""
