# Stage 17P — Current State / Forward Plan Baseline

> Preserved baseline/reference document. Keep using `docs/ROADMAP.md` as the
> current control document for what happens next. This file remains useful for
> planner truth, source-authority rules, and historical boundary context.

Stage 17P is a documentation-control stage. It does not implement app behaviour, change backend mechanics, alter scoring, change CP formulas, add ingestion, change persistence, or redesign the Colony Planner UI.

## Purpose

The colonisation roadmap has grown through many implementation and recovery stages. Older documents are still valuable, but several of their "next stage" recommendations are now historical because later work has already landed.

This document is the current planning baseline for future Colony Planner, colonisation intelligence, trust, slot, enrichment, and whole-system planner work.

Stage 22 is now the active post-21 control document for deciding what happens
next. This file remains the product-boundary baseline for planner truth,
mechanics safety, and source-authority rules.

Future implementation prompts should read this file first, then inspect the specific historical stage document only when it is relevant evidence for the work being planned.

## Current Baseline

The project has moved beyond the original Stage 17A sequence of:

1. trust/rationale fixes,
2. surface slot prediction,
3. structure picker expansion,
4. validity hardening,
5. visual planner feasibility,
6. durable persistence feasibility,
7. ingestion feasibility.

That sequence remains useful as historical intent, but it has been partly superseded by later merged work.

Current merged direction, based on the latest roadmap trail:

- Stage 16E/16F/16G added inferred, declared, and declared-vs-observed role review concepts while keeping roles advisory and non-mechanical.
- Stage 17B rescued Suggested Builds error handling and usefulness filtering.
- Stage 17G introduced canonical validated slot prediction and a whole-system slot/economy planning map.
- Stage 17M moved the dedicated planner toward a two-region whole-system planner canvas plus telemetry/context model.
- Stage 17N tightened the docked telemetry/context region and read-only projection comparison.
- Stage 17N.1 repaired and refined planner canvas add flows, picker compatibility, lane handling, prerequisite warnings, and canvas clarity.
- Stage 17N.2c recovered trust around unknown coordinates, unknown distances, stale/saturated ratings, and legacy rationale language.
- Stage 17N.2d/17N.2d-H moved existing-infrastructure awareness and station/body association toward backend-backed trust metadata.
- Stage 17N.2d-P and the enrichment roadmap introduced a safer offline/staging warehouse direction for repeatable enrichment evidence and report-only reconciliation.
- Stage 18J-Q8 keeps the first production-scale reconciliation review offline
  and compact: large artifacts must be summarized before Stage 18J-P can
  proceed, and production summaries remain non-git by default.

## Read-Order For Future Work

Use this order before starting new colonisation work:

1. `docs/ROADMAP.md`
2. `docs/colonisation-redesign/README.md`
3. This file.
4. `docs/colonisation-redesign/stage-25c-product-shell-shared-context-contract.md` for the active implementation contract.
5. `docs/reference/colonisation/README.md`, `docs/reference/colonisation/source-priority.md`, and `docs/reference/colonisation/source-inventory.md` for mechanics-heavy or source-sensitive work.
6. `docs/operations/enrichment-warehouse-runbook.md` for guarded enrichment and warehouse operations.
7. `docs/colonisation-redesign/stage-19-bounded-production-staging-activation.md` when work touches the separate bounded production-staging dependency.
8. Specific historical stage docs only when they directly apply to the task.

If this file conflicts with an older "recommended next stage" section, treat this file as newer planning control unless the older doc is being used only for historical context.

## Source Authority Rule

The source-pack issue from Stage 17A remains important, but Stage 17Q now adds
the committed reference entry point:

- `docs/reference/colonisation/README.md`
- `docs/reference/colonisation/source-priority.md`
- `docs/reference/colonisation/source-inventory.md`
- `docs/reference/colonisation/codex-reference-prompt-snippet.md`

The committed path records the source hierarchy, conflict rules, and inventory
placeholders. It does not commit restricted guide files, spreadsheets, PDFs,
screenshots, or third-party assets unless their redistribution status is
explicitly safe.

Future mechanics-heavy implementation prompts must read the committed reference
docs first, then explicitly state whether direct source verification used
committed docs, attached files, external sources, or local/operator-only files.
Do not claim direct source verification from files that are not committed or
attached.

## Non-Negotiable Product Boundaries

These boundaries continue to apply unless a future stage explicitly changes them:

- No automatic Simulation Preview execution.
- No automatic Suggested Build generation.
- No automatic Suggested Build loading.
- No silent Build Plan mutation from imported, observed, projected, or inferred data.
- No hidden scoring, CP, economy, service, buildability, or optimiser-ranking changes.
- No role-aware optimiser scoring/ranking without a dedicated scope.
- No primary-port truth invented from user intent.
- No Architect Slot Survey truth unless backed by an explicit evidence/import workflow.
- No reference planner visual clone, asset copy, API mutation, or logistics clone.
- Existing infrastructure is not a Build Plan placement.
- Projected Suggested Build structures are ghost/projection-only until explicitly loaded.
- Unknown data must stay unknown; do not coerce missing coordinates, distances, slot counts, rings, or body associations to zero/false.

## Current Information Model

The planner should keep these concepts visibly separated:

| Source | Meaning | Mutates Build Plan? | Trust handling |
|---|---|---:|---|
| Existing | Infrastructure already present in system/station data | No | Confirmed, inferred/verify, or unresolved based on backend association metadata. |
| Planned | User Build Plan placements | Yes | Local project/user plan state. |
| Projected | Selected Suggested Build ghost placements | No | Read-only comparison until explicitly loaded. |
| Observed Evidence | Manual/imported evidence records | No by default | Used for review/validation; does not mutate mechanics. |
| Inferred Planning Signals | ED-Finder advisory hints from topology/plan shape | No | Conservative guidance only. |
| Declared Strategy | User-declared body roles | No mechanics mutation | Local project intent, not game truth. |
| Unknown/Unresolved | Missing/ambiguous data | No | Display compactly and conservatively. |

## Recommended Next Work Queue

### Stage 17Q — Source Pack Commit / Source Authority Lock

Purpose: make the mechanics/source hierarchy available in-repo so future mechanics-heavy work has a committed reference baseline.

Scope:

- Add `docs/reference/colonisation/README.md`.
- Add `docs/reference/colonisation/source-priority.md`.
- Add the future implementation prompt snippet.
- Add permitted source references, inventories, or placeholders.
- Document licensing/redistribution limits where source files cannot be committed.

Non-goals:

- No app behaviour changes.
- No mechanics changes.
- No scoring changes.

Acceptance:

- Future Codex/AI prompts can start from committed source-priority docs.
- The repo no longer points only at a local ZIP path for the reference pack.

### Stage 17R — Planner Trust Audit

Status: advanced in Stage 21 and satisfied for the current planner baseline.

Purpose: verify the current whole-system planner and trust-recovery work behaves honestly on real awkward systems before adding more intelligence.

Scope:

- Audit current planner canvas behaviour against systems with known existing stations, predicted slots, unresolved associations, and projected Suggested Builds.
- Remove any temporary slot/debug console logs.
- Confirm unknown coordinates/distances never render as real zero values.
- Confirm stale/saturated rating caveats and legacy-rationale safety copy are still present where needed.
- Confirm predicted slots never appear as known/confirmed slots.
- Confirm existing infrastructure never silently becomes planned infrastructure.
- Add focused regression tests around representative awkward systems/fixtures.

Non-goals:

- No new planner features.
- No scoring changes.
- No automatic preview/generation/load.

Acceptance:

- Trust language is consistent between result cards, system detail, planner canvas, and telemetry.
- Ambiguous station/body/lane associations render as unresolved or verify, not confirmed.
- Capacity calculations clearly separate predicted, existing, planned, projected, and unknown states.

### Stage 17S — Existing Infrastructure UX Hardening

Status: advanced in Stage 21 and satisfied for the current planner baseline.

Purpose: make existing infrastructure and occupied-slot reasoning understandable to the user.

Scope:

- Improve display for confirmed existing, inferred/verify existing, unresolved, and unknown-lane infrastructure.
- Add compact explanations/tooltips for association source and confidence.
- Make capacity math visible per lane: predicted slots, existing occupied, planned occupied, projected occupied, remaining, unknown/unresolved.
- Ensure disabled add controls explain the exact reason.

Non-goals:

- No Build Plan mutation from existing infrastructure.
- No canonical write path.
- No new enrichment ingestion.

Acceptance:

- A user can tell why a slot is unavailable.
- A user can tell whether ED-Finder knows, infers, or cannot resolve an existing station's body/lane.

### Stage 17T — Suggested Builds Strategy Advisor V1

Status: advanced in Stage 21 and satisfied for the current planner baseline.

Purpose: make Suggested Builds more strategically useful using the planner context already available.

Scope:

- Improve candidate explanation around body choice, existing infrastructure, slot pressure, economy intent, sparse-data warnings, and declared roles.
- Keep deterministic candidate families such as main station candidate, industrial/refinery starter, extraction support, tourism/agriculture, security/military, balanced expansion, and support-body plan.
- Use planner canvas projection to make candidate impact clearer.
- Keep load explicit and preview explicit.

Non-goals:

- No LLM planning.
- No automatic generation/load/preview.
- No hidden optimiser-ranking mechanics change unless separately scoped.

Acceptance:

- Suggested Builds explain why they exist and what tradeoff they are making.
- Trivial candidates stay filtered.
- Projected structures remain ghost-only until explicit load.

### Stage 17U — Role + Strategy Integration

Status: advanced in Stage 21 and satisfied for the current planner baseline.

Purpose: connect declared/inferred/observed role work to Suggested Builds and planner guidance without making roles mechanics truth.

Scope:

- Show which declared roles a candidate supports or conflicts with.
- Surface role gaps such as declared Industrial Core with no industrial placement, Main Station Body with no station/port, or observed Tourism Focus conflicting with declared Industrial Core.
- Keep source labels visible: inferred, declared, observed.

Non-goals:

- No role-aware optimiser ranking.
- No role-driven Simulation Preview mechanics.
- No automatic declared-role assignment from Suggested Builds.

Acceptance:

- Roles improve guidance and review.
- Roles still do not change CP, economy, service, scoring, optimiser ranking, or validation semantics.

### Stage 18A — Enrichment Operator Dashboard / Status Integration

Status: delivered.

Purpose: make enrichment status observable without SSH/log spelunking.

Scope:

- Surface `station_enrichment_status.py --json` in an operator/admin dashboard.
- Display latest run, checkpoint progress, fetch/rate-limit failures, safety-gate failures, and batch status.
- Keep the dashboard read-only.

Non-goals:

- No production writes from dashboard.
- No live API crawling from dashboard.

Acceptance:

- Operator can inspect progress and failures through ED-Finder UI/admin tooling.
- Status is read-only and safe.

### Stage 18B — Warehouse Reconciliation Hardening

Status: delivered as report-only warehouse groundwork.

Purpose: mature the offline enrichment warehouse path before any canonical writes are considered.

Scope:

- Broaden read-only reconciliation across staged station, body, and ring evidence.
- Improve confidence/risk explanations.
- Improve source coverage summaries, colonisation signals, and mission-density signals.
- Keep output report-only.

Non-goals:

- No canonical station/body/system writes.
- No production live API crawl.
- No scoring changes.

Acceptance:

- Warehouse reports are boring, deterministic, and explainable.
- Any future canonical write path can be designed from stable report evidence rather than live API behaviour.

### Stage 18C — Warehouse Runbook + Operator Workflow

Status: delivered.

Purpose: make the warehouse safe and repeatable to run.

Runbook: `docs/operations/enrichment-warehouse-runbook.md`.

Scope:

- Document where snapshots come from, where they are stored, how they are loaded, and how dry-run reconciliation is run.
- Define what a good run looks like, which warnings block progress, and what should never write canonical data.
- Provide operator commands for fixture, staging, and production-read-only dry-runs.

Non-goals:

- No canonical writes.
- No production scheduler/job wiring unless separately scoped.

Acceptance:

- A future operator can run the warehouse path without guessing which script or flags to use.
- Dry-run/report-only behaviour remains the default.

### Stage 18D — Snapshot Source Normalisation

Status: delivered.

Purpose: make snapshot inputs predictable and explainable.

Scope:

- Harden source metadata, source timestamps, source freshness, malformed-row handling, skipped-row reasons, and source-format versioning for station and body/ring snapshots.
- Prepare for future Spansh-style body/ring source shapes without silently merging conflicting semantics.

Non-goals:

- No live API crawl.
- No canonical writes.

Acceptance:

- Bad or incomplete source files produce clear skipped-row/error summaries instead of partial mystery loads.

### Stage 18E — Warehouse Coverage Reports

Status: delivered.

Purpose: show how complete the warehouse evidence is.

Scope:

- Report systems with/missing station evidence.
- Report bodies with trusted/unknown ring evidence.
- Report stations with confirmed, inferred/verify, and unresolved body links.
- Report stale evidence and high-value systems needing better evidence.

Non-goals:

- No canonical writes.
- No planner mutation.

Acceptance:

- The warehouse can answer what evidence coverage exists and what remains unknown.

### Stage 18F — Reconciliation Confidence Model

Status: delivered.

Purpose: make reconciliation explain itself.

Scope:

- Add or harden confidence levels, reasons, source freshness, risk classes, and report-only/canonical-eligible markers for reconciliation candidates and conflicts.
- Preserve volatile fields such as `distanceToArrival` as volatile evidence, not churn sources.

Non-goals:

- No canonical writes.
- No automatic canonical eligibility promotion.

Acceptance:

- Each important reconciliation decision can explain why it is safe, risky, stale, volatile, or blocked.

### Stage 18G — Warehouse Operator Dashboard

Status: delivered.

Purpose: expose warehouse-specific run and evidence status in a read-only operator surface.

Scope:

- Show latest snapshot loads, latest reconciliation run, source coverage, unresolved count, risky conflicts, stale warnings, report links, and whether canonical tables were untouched.

Non-goals:

- No write controls.
- No live API crawling.
- No canonical writes.

Acceptance:

- Operators can inspect warehouse state without SSH while preserving read-only boundaries.

### Stage 18H — Warehouse-to-Planner Evidence Bridge, Read-Only

Purpose: let the planner see warehouse evidence as evidence, not truth.

Scope:

- Surface selected warehouse evidence context such as available verify station/body evidence, ring evidence, stale/conflicting enrichment state, or newer report-only evidence.
- Keep all warehouse-derived planner context source-labelled and non-mutating.

Non-goals:

- No planner mutation.
- No scoring, CP, economy, service, buildability, Simulation Preview, or optimiser changes.
- No automatic promotion to canonical truth.

Acceptance:

- The planner can display warehouse evidence context without treating report-only evidence as canonical data.

Status: delivered (conservative placeholder path). The Stage 18G warehouse
artifact is admin-gated and aggregate-only, so per-system linking is not yet
safe. Stage 18H shipped a typed read-only `PlannerWarehouseEvidence` model, a
compact source-labelled planner card defaulting to a safe unavailable/unknown
state, no-mutation tests, and a design doc with the future per-system
integration path
(`stage-18h-warehouse-planner-evidence-bridge.md`). No backend endpoint, no live
calls, no canonical or planner state mutation.

### Stage 18I — Canonical Write Design Review

Purpose: design, but not implement, the rules for promoting warehouse evidence into canonical data.

Scope:

- Define which findings could ever write canonical tables, which must remain evidence-only, required confidence, manual approval, audit trail, rollback, table scope, and banned writes.

Non-goals:

- No write-path implementation.
- No canonical data mutation.

Acceptance:

- Stage 18J cannot begin until this design review clearly defines the promotion boundary.

Design review: `stage-18i-canonical-write-design-review.md`. Stage 18I remains
documentation-only and does not authorize canonical writes. It recommends exact
station type promotion as the first Stage 18J pilot only after Stage 18I.5
settles the warehouse database boundary.

### Stage 18I.5 — Warehouse Database Boundary Review

Purpose: decide and document the storage boundary before canonical write pilots begin.

Preferred direction:

- Use **Option B now** if feasible: a separate database on the same Postgres server/stack, for example `edfinder_enrichment`.
- Keep **Option C compatible later**: design the warehouse so it can move to a separate Postgres instance/server if load, retention, or operational risk justify it.

Scope:

- Decide same DB/schema vs same server/separate DB vs separate instance.
- Define proposed database name, connection strings, environment variables, migration ownership, and migration path.
- Define permissions for app user, warehouse loader, warehouse reader, and canonical apply user.
- Decide whether reconciliation uses canonical snapshot copies, read-only views, FDW, or direct read-only access.
- Define backup/restore, retention, performance-isolation expectations, and how write plans cross into guarded canonical apply.
- Explicitly ban direct warehouse mutation of canonical app tables.

Non-goals:

- No canonical writes.
- No production migration of the warehouse DB unless separately approved.
- No planner behaviour changes.
- No scoring, CP, economy, service, buildability, Simulation Preview, or optimiser changes.

Acceptance:

- The repo contains a clear B-vs-C decision document.
- The recommendation is explicit: separate `edfinder_enrichment` database now if feasible, with a clean route to a separate instance/server later.
- Future Stage 18J cannot start until this boundary review is complete.

Boundary review: `stage-18i5-warehouse-database-boundary-review.md`.
Stage 18I.5 recommends Option B, a separate `edfinder_enrichment` database on
the same Postgres stack if feasible, while preserving Option C as the future
separate-instance path. It remains documentation-only and does not create
databases, users, permissions, or migrations.

### Stage 18J — First Narrow Canonical Write Pilot

Purpose: prove one narrow canonical write path can be trusted.

Scope:

- Choose one tiny, low-risk canonical write path such as exact station type promotion, exact confirmed station/body link promotion, or trusted ring rows only if source semantics are strong enough.
- Require dry-run, guarded apply, audit trail, rollback information, conflict blocking, and post-apply verification.

Non-goals:

- No broad canonical backfill.
- No unrestricted warehouse-to-canonical writes.
- No planner mutation beyond reading already-canonical data.

Acceptance:

- One narrow canonical write path is proven safe, auditable, reversible, and boring before any wider canonical expansion.

Stage 18J delivered the station type canonical pilot as the first
canonical-write-capable path. Production apply remains unauthorized unless a
separate future instruction approves the exact artifact, candidate count,
source run/file, table, field, max row count, and apply DSN context.

### Stage 18T — Canonical Safety Test Environment

Purpose: make canonical-write-capable test coverage repeatable in CI and local
development before further production dry-run or apply work.

Scope:

- Add a dedicated canonical safety CI job.
- Install explicit test prerequisites, including `pytest-asyncio`.
- Add a local one-command canonical safety test runner.
- Add disposable Postgres rehearsal and permission-boundary tests for the
  guarded Stage 18J station type apply path.

Non-goals:

- No production apply.
- No production artifact.
- No production DB access.
- No broad canonical backfill.
- No UI/API apply controls or scheduler wiring.

Acceptance:

- The canonical safety suite runs consistently in CI and locally.
- Disposable Postgres rehearsal proves the guarded apply path and scoped
  permissions without touching production.

Environment doc: `stage-18t-canonical-safety-test-environment.md`.

### Stage 18J-Q — Production Reconciliation Artifact Readiness

Purpose: prepare the missing report-only production reconciliation artifact
prerequisite before Stage 18J-P can generate a station-type production dry-run.

Scope:

- Search local/configured artifact locations for a suitable
  `enrichment_staging_reconciliation/v1` production artifact.
- Define the required artifact contract, read-only generation path,
  DSN/access safety checks, sanitisation checks, and stop conditions.
- Keep production apply and production artifact approval blocked.

Non-goals:

- No production apply.
- No production canonical data changes.
- No approved station-type dry-run artifact.
- No broad canonical backfill.
- No UI/API apply controls or scheduler wiring.

Acceptance:

- The repo documents whether a suitable artifact exists.
- Stage 18J-P proceeds only if a verified report-only artifact exists and
  passes the Stage 18J-Q contract.

Readiness doc:
`stage-18j-q-production-reconciliation-artifact-readiness.md`.

### Stage 18J-Q2 — Read-Only Production Reconciliation Plan

Purpose: define the exact safe command path for producing the missing
production reconciliation artifact in a later explicitly approved operation.

Scope:

- Identify the existing `--report-reconciliation` tooling.
- Define required staged warehouse inputs, read-only DSN/access proof,
  environment variables, output path, artifact contract checks, and stop
  conditions.
- Keep Stage 18J-P, production reconciliation execution, station-type dry-run
  generation, and production apply blocked.

Non-goals:

- No production-connected reconciliation command execution.
- No production reconciliation artifact generation.
- No production station-type dry-run artifact.
- No production apply or approval.

Acceptance:

- The repo contains a precise operator plan for the later read-only/report-only
  reconciliation command.
- Stage 18J-P remains blocked until a verified artifact exists and passes the
  contract checks.

Plan doc:
`stage-18j-q2-readonly-production-reconciliation-plan.md`.

### Stage 18J-Q3 — Read-Only Production Reconciliation Artifact

Purpose: run the read-only/report-only production reconciliation artifact
generation path only if all pre-run safety checks are satisfied.

Scope:

- Verify the command shape, read-only DSN/access, approved source run/file,
  read-only session option, and operator-managed output path.
- Generate and validate the `enrichment_staging_reconciliation/v1` artifact
  only when those gates pass.
- Stop and document blockers before any production-connected command if any
  gate is missing.

Current result:

- The pre-run gate failed because no verified read-only/report-only DSN,
  approved source run/file, read-only session option, or operator-managed
  output path was available.
- No production-connected reconciliation command was run.
- No production artifact was generated or approved.
- Stage 18J-P remains blocked.

Report:
`stage-18j-q3-readonly-production-reconciliation-artifact.md`.

### Stage 18J-Q4 — Operator Access Packet

Purpose: define the safe operator checklist for providing the variables that
Stage 18J-Q3 lacked.

Scope:

- Document the required read-only/report-only DSN, source run/file keys,
  operator-managed artifact directory, and mandatory read-only `PGOPTIONS`.
- Provide a redacted command template that matches the real loader CLI.
- Define secret handling, sign-off, and rerun criteria without committing real
  DSNs, credentials, hostnames, or production artifact paths.

Non-goals:

- No production-connected reconciliation command execution.
- No production artifact generation or approval.
- No station-type dry-run generation.
- No production apply or canonical data changes.

Access packet:
`../operations/stage-18j-q4-operator-access-packet.md`.

### Stage 18J-Q4b/Q4c — Read-Only Warehouse DSN Operator Prep

Purpose: document the missing read-only/report-only warehouse DSN and the
operator plan to provision it safely before Stage 18J-Q3 is retried.

Scope:

- Confirm the repo does not already define a usable
  `EDFINDER_WAREHOUSE_READ_DSN`.
- Explain why a local/dev checkout such as DAVE2 is not sufficient unless it
  has separately approved deployment database administration access.
- Define the required read/report role properties, forbidden permissions,
  private environment variables, redacted verification steps, and Q3 retry
  criteria.

Non-goals:

- No production-connected reconciliation command execution.
- No production artifact generation or approval.
- No role creation, grant changes, deployment config changes, or database
  access.
- No station-type dry-run generation.
- No production apply or canonical data changes.

Operator note:
`../operations/stage-18j-q4b-readonly-warehouse-dsn-operator-note.md`.

Provisioning plan:
`../operations/stage-18j-q4c-readonly-warehouse-dsn-provisioning-plan.md`.

### Stage 18J-Q5 — Nested EDSM Station Snapshot Support

Purpose: support the nested EDSM system station snapshot shape observed on the
server without committing production data or running production loads.

Scope:

- Preserve full source system records as raw warehouse evidence.
- Extract deterministic station staging rows from nested `stations` arrays.
- Preserve source run/file keys, station source hashes, parent raw provenance,
  station identity, and station-type labels.
- Keep nested `bodies` collections as raw-only unsupported-source-shape
  warning evidence.

Non-goals:

- No production load.
- No production reconciliation.
- No station-type dry-run.
- No canonical apply.
- No Stage 18J-P or Stage 18K work.

Support doc:
`stage-18j-q5-nested-edsm-station-snapshot-support.md`.

### Stage 18J-Q6 — Memory-Safe Warehouse Station Load

Purpose: make the explicit station warehouse staging load safe for the large
nested EDSM station snapshot after the post-Q5 full load attempt was killed.

Scope:

- Stream `edsm_nightly_stations` source records in write-staging mode.
- Add source-record batch sizing for station writes.
- Keep dry-run as the default/no-write full report path.
- Emit compact write summaries instead of materializing every raw/staged row
  in the final JSON output.
- Document idempotent retry expectations for interrupted staging loads.

Non-goals:

- No production load during the development stage.
- No production reconciliation or artifact generation.
- No station-type dry-run.
- No canonical apply.
- No scheduler/cron implementation.
- No Stage 18J-P or Stage 18K work.

After Q6 merges, the next server action is a controlled retry of the warehouse
station staging load. If that succeeds, move to read-only reconciliation
artifact generation. Stage 18J-P remains blocked until a valid reconciliation
artifact exists.

Support doc:
`stage-18j-q6-memory-safe-warehouse-station-load.md`.

### Stage 18J-Q7 — Reconciliation JSON Serialization Fix

Purpose: fix the read-only reconciliation artifact path after the first
post-Q6 reconciliation attempt failed while printing JSON.

Scope:

- Convert DB-native reconciliation report values such as datetimes, dates, and
  decimals into deterministic JSON-safe values.
- Preserve `enrichment_staging_reconciliation/v1` content and deterministic
  `sort_keys=True` output.
- Keep station candidates and `canonical_writes_planned = 0` visible.
- Document the 0-byte artifact failure and the blocked Stage 18J-P state.

Non-goals:

- No production reconciliation run from development.
- No production artifact generation or approval.
- No station-type dry-run.
- No canonical apply.
- No production DB access.
- No Stage 18J-P or Stage 18K work.

Q7 fixes serialization only. Stage 18J-P remains blocked until a valid
read-only reconciliation artifact exists.

Support doc:
`stage-18j-q7-reconciliation-json-serialization-fix.md`.

### Stage 18J-Q8 - Compact Reconciliation Summary

Purpose: make the valid large reconciliation artifact reviewable without
loading or committing the full production artifact.

Scope:

- Add an offline CLI that streams an existing
  `enrichment_staging_reconciliation/v1` JSON artifact in bounded memory.
- Output source basename only, SHA-256, file size, schema,
  `canonical_writes_planned`, candidate counts, update/insert counts, blocking
  reasons, confidence/risk counts, coverage counts, and capped sanitized
  candidate samples.
- Exclude raw payloads, private paths, DSNs, and secrets from the compact
  output.
- Mark compact output `safe_for_git = false` by default.

Non-goals:

- No production reconciliation run from development.
- No production data or artifact commits.
- No station-type dry-run.
- No canonical apply.
- No production DB access.
- No Stage 18J-P or Stage 18K work.

Q8 is a review-enabling extraction step only. Stage 18J-P remains blocked until
a compact review output exists and is explicitly reviewed.

Support doc:
`stage-18j-q8-compact-reconciliation-summary.md`.

### Stage 19A - Warehouse Artifact Taxonomy and Chunked Roadmap

Purpose: define how warehouse artifacts are named, separated, reviewed, and
sequenced before Stage 19 broadens beyond station reconciliation.

Scope:

- Separate artifact families for stations, bodies, rings, station/body links,
  markets, services, economies, colonisation, freshness, coverage, analytics,
  and future write plans.
- Standardize domain-qualified artifact names for loads, reconciliation,
  compact summaries, freshness status, operator status, and future write plans.
- Require source inventory before load, load before reconciliation,
  reconciliation before compact summary, compact summary before dry-run,
  dry-run before approval packet, approval packet before apply, and manual
  apply only.
- State that scheduler work must remain disabled by default and must never run
  canonical apply.
- Preserve the Stage 18J continuation path: Q9 compact review, strict-filter
  hardening, operator-safe dry-run wrapper, P2 identity diagnostics, P3/P4
  external identity design, P5 migration draft, P6 production readiness review,
  P7 schema production apply closeout, P8 evidence loader/reconciliation
  design, P9 read-only identity candidate artifact, P10 candidate artifact
  review, P11 bounded no-write load-plan artifact, P-OPT execution board,
  Chunk A P12/P13 review pack, Chunk B P14 controlled identity load tooling,
  Chunk C P15 post-load identity coverage, Chunk D P16 reconciliation
  integration with confirmed identity, and Chunk E P17 strict station-type
  dry-run retry.

Non-goals:

- No production commands.
- No production DB access.
- No imports, reconciliation, station-type dry-run, or apply.
- No cron/scheduler wiring.
- No Stage 18J-P or Stage 18K work.

Support doc:
`docs/ROADMAP.md`.

### Stage 18J-Q9 - Compact Summary Review / Station-Type Dry-Run Readiness

Purpose: review the valid compact reconciliation summary and decide whether
Stage 18J-P can retry the station-type production dry-run.

Scope:

- Record compact summary counts for station candidates, update candidates,
  missing-canonical insert candidates, ambiguous matches, confidence/risk
  distributions, and station/body association blockers.
- Set the readiness verdict to `Ready only with strict filter`.
- Require external identity proof, non-ambiguous canonical match, non-volatile
  evidence, permanent station type, station-type-only scope, no station/body
  association writes, no source-only inserts, and an explicit max-row bound
  before any Stage 18J-P retry.

Non-goals:

- No production commands.
- No production DB access.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No artifact approval or approval record.
- No Stage 18J-P or Stage 18K work.

Support doc:
`stage-18j-q9-compact-summary-review-station-type-dry-run-readiness.md`.

### Stage 18J-P-filter - Strict Station-Type Dry-Run Filter Hardening

Purpose: harden the station-type dry-run eligibility filter before any future
Stage 18J-P production dry-run retry.

Scope:

- Require explicit external station identity proof by matching `market_id` or
  matching `edsm_station_id`; internal canonical `station_id` is not identity
  proof.
- Reject ambiguous identity, source-only inserts, volatile evidence,
  transient/non-slot station types, non-station-type changes, missing
  station-type deltas, and candidates outside the explicit max-row bound.
- Preserve `missing_station_body_name` as a station/body-link blocker while
  allowing externally proven station-type comparisons.
- Keep dry-run output at `canonical_writes_planned = 0`, record the input
  reconciliation artifact checksum, and report explicit rejection counts.
- Add synthetic tests only.

Non-goals:

- No production commands.
- No production DB access.
- No imports, reconciliation, production summarizer run, production
  station-type dry-run, or canonical apply.
- No approval record.
- No Stage 18J-P or Stage 18K work.

Support doc:
`stage-18j-p-filter-strict-station-type-dry-run-filter.md`.

### Stage 18J-P-dryrun-ops - Operator-Safe Station-Type Dry-Run Wrapper

Purpose: add the Hetzner-only wrapper and compact-output controls required
before any future Stage 18J-P production station-type dry-run.

Scope:

- Add `scripts/operator/stage18j_run_station_type_dry_run.sh`.
- Require the shared Hetzner operator environment guard.
- Verify the validated reconciliation artifact checksum before dry-run.
- Require bounded `MAX_ROWS`, with first-pilot refusal above `20`.
- Write the dry-run artifact under the operator artifact directory.
- Cap blocked candidate samples while preserving full rejection counts and
  total candidate counts.
- Print compact summary fields and artifact checksum.

Non-goals:

- No production commands from Codex.
- No production DB access.
- No imports, reconciliation, production summarizer run, production
  station-type dry-run, or canonical apply.
- No approval record.
- No Stage 18J-P or Stage 18K work.

Support doc:
`stage-18j-p-dryrun-operator-safe-wrapper.md`.

### Stage 18J-P2 - Station-Type Identity Coverage Diagnostics

Purpose: explain why the first bounded operator station-type dry-run produced
zero eligible update candidates after every candidate failed external identity
proof.

Scope:

- Add count-only `identity_coverage_summary` to the strict station-type dry-run
  artifact.
- Count source/canonical `market_id` and `edsm_station_id` presence, matches,
  and mismatches.
- Count `system_id64` and station-name matches and mismatches.
- Count canonical match distribution and canonical station rows whose external
  IDs are absent from the reconciliation payload.
- Keep the strict filter unchanged and keep `canonical_writes_planned = 0`.
- Support a future bounded Hetzner/operator diagnostic rerun.

Non-goals:

- No production commands from Codex.
- No production DB access.
- No imports, reconciliation, production summarizer run, production
  station-type dry-run, or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p2-station-type-identity-coverage-diagnostics.md`.

### Stage 18J-P3 - Canonical External Station Identity Model

Purpose: record why Stage 18J-P produced zero eligible station-type candidates
under the strict filter and identify the missing canonical external identity
model.

Scope:

- Confirm canonical `stations` has no `market_id` or `edsm_station_id`.
- Confirm existing `s.id AS market_id` usage is a compatibility alias/update
  target, not external identity proof.
- Confirm `station_body_links.market_id` is association-scoped and not a
  general external station identity registry.
- Recommend a separate provenance-backed `station_external_identity` table.
- Keep the strict station-type filter unchanged.

Non-goals:

- No production commands.
- No production DB access.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p3-canonical-external-station-identity-model.md`.

### Stage 18J-P4 - External Station Identity Schema Design

Purpose: design the external station identity schema that can eventually let
read-only reconciliation prove canonical station identity with explicit
external IDs.

Scope:

- Define a separate `station_external_identity` table shape.
- Preserve `canonical_station_id`, `system_id64`, station name, source,
  nullable `market_id`, nullable `edsm_station_id`, source run/file/hash
  provenance, source update time, evidence first/last seen timestamps,
  confidence, freshness, identity status, and conflict reason.
- Use statuses `proposed`, `confirmed`, `conflicting`, `rejected`, and
  `superseded`.
- Allow only `confirmed` rows to serve as read-only reconciliation proof.
- Keep station-type writes blocked until confirmed external identity is
  available.
- Recommend a draft migration first, then a separate production readiness
  review before any schema application, identity evidence load, or dry-run
  retry.

Non-goals:

- No live SQL migration under `sql/`.
- No production commands.
- No production DB access.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p4-external-station-identity-schema-design.md`.

### Stage 18J-P5 - External Station Identity Migration Draft

Purpose: draft the additive schema migration for the external station identity
model without applying it to production.

Scope:

- Add `sql/027_station_external_identity.sql`.
- Create `station_external_identity` with canonical station reference,
  `system_id64`, station name, source, nullable `market_id`, nullable
  `edsm_station_id`, source run/file/hash provenance, source update time,
  evidence first/last seen timestamps, confidence, freshness, identity status,
  conflict reason, and timestamps.
- Require at least one external ID.
- Allow identity statuses `proposed`, `confirmed`, `conflicting`, `rejected`,
  and `superseded`.
- Add partial unique indexes for confirmed external identities and lookup
  indexes for station, system, external IDs, source run/file, and status.
- Add migration contract tests for constraints, indexes, status behavior,
  additive scope, and no station-type write implication.

Non-goals:

- No production commands.
- No production DB access.
- No production migration apply.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p5-external-station-identity-migration-draft.md`.

### Stage 18J-P6 - External Identity Migration Production Readiness Review

Purpose: review `sql/027_station_external_identity.sql` before any production
schema application stage.

Scope:

- Confirm the migration is additive and schema-only.
- Confirm it does not alter `stations`.
- Confirm it does not write canonical station-type data.
- Review constraints, indexes, provenance fields, conflict handling, rollback
  expectations, preflight checks, and post-apply checks.
- Record the readiness verdict for a future schema-only Hetzner operator stage.
- Keep identity evidence loading, reconciliation, station-type dry-run, and
  canonical apply blocked.

Non-goals:

- No production commands.
- No production DB access.
- No production migration apply.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p6-external-identity-migration-production-readiness.md`.

### Stage 18J-P7 - External Identity Schema Production Apply Closeout

Purpose: record that `sql/027_station_external_identity.sql` has been applied
on Hetzner as a schema-only migration after the P6 readiness review.

Scope:

- Record that `station_external_identity` exists in production.
- Record that `station_external_identity` row count is `0`.
- Record that canonical `stations` count after apply is `284763`.
- Record the verified constraints and indexes.
- Confirm no identity evidence was loaded.
- Confirm no imports, reconciliation, production summarizer run, station-type
  dry-run, or canonical apply were run.
- Confirm no station-type data changed.
- Keep strict station-type dry-run blocked until confirmed identity evidence is
  loaded and integrated into read-only reconciliation.

Non-goals:

- No production commands from Codex.
- No production DB access from Codex.
- No production migration reapply.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p7-external-identity-schema-production-apply-closeout.md`.

### Stage 18J-P8 - External Identity Evidence Loader / Reconciliation Design

Purpose: design how external station identity evidence will be loaded and
reconciled into the now-present `station_external_identity` table.

Scope:

- Identify `edsm_nightly_stations` warehouse evidence as the first identity
  source candidate.
- Map `staging_edsm_stations` fields to `station_external_identity`.
- Define candidate matching rules using external IDs, source provenance,
  `system_id64`, normalized station name, and exactly one canonical station
  match.
- Define `proposed`, `confirmed`, `conflicting`, `rejected`, and `superseded`
  status rules.
- Define a read-only identity candidate artifact before any identity writes.
- Define future write-staging/load boundaries for `station_external_identity`
  only.
- Keep strict station-type dry-run blocked until confirmed identity coverage is
  reviewed and exposed through read-only reconciliation.

Non-goals:

- No production commands.
- No production DB access.
- No identity evidence load.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p8-external-identity-evidence-loader-reconciliation-design.md`.

### Stage 18J-P9 - Read-only External Identity Candidate Artifact

Purpose: implement a read-only artifact generator that proposes external
station identity candidates from staged EDSM station evidence.

Scope:

- Add `apps/importer/src/station_external_identity_candidates.py`.
- Read staged EDSM station evidence through an explicit read-only DSN.
- Require `--source-run-key` and support `--source-file-key`, `--limit`,
  `--sample-limit`, `--json`, and `--output`.
- Match candidates by source `system_id64` and normalized station name.
- Emit candidate statuses `confirmed_candidate`, `proposed`, `conflicting`,
  and `rejected`.
- Preserve source run/file/hash provenance and source external IDs.
- Emit compact deterministic JSON with capped samples and an integrity hash.
- Add synthetic tests for status classification, provenance, no-write SQL,
  deterministic JSON, sample caps, and write/apply flag rejection.

Non-goals:

- No production commands.
- No production DB access.
- No writes to `station_external_identity`.
- No identity evidence load.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p9-readonly-external-identity-candidate-artifact.md`.

### Stage 18J-P10 - External Identity Candidate Artifact Review

Purpose: review the first Hetzner read-only external station identity candidate
artifact and decide whether the result is ready for a future identity evidence
load path.

Scope:

- Record artifact
  `station_external_identity_candidates_20260603T002504Z.json`, its path, size,
  SHA-256, integrity SHA-256, source run/file filters, and schema version.
- Record read-only safety fields: `dry_run = true`, `read_only = true`,
  `report_only = true`, `canonical_writes_planned = 0`,
  `station_type_writes_planned = 0`, and `identity_rows_written = 0`.
- Record candidate counts: `261938` `confirmed_candidate`, `258`
  conflicting, `35981` rejected/source-only, and `0` proposed.
- Record source identity coverage and canonical match coverage.
- Interpret `confirmed_candidate` as reviewable artifact evidence only, not as
  production-confirmed external identity.
- Set readiness verdict to `Ready only for bounded identity load dry-run`.
- Require the next stage to produce a bounded no-write load-plan artifact before
  any controlled insert into `station_external_identity`.

Non-goals:

- No production commands from Codex.
- No production DB access from Codex.
- No identity evidence load.
- No writes to `station_external_identity`.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p10-external-identity-candidate-artifact-review.md`.

### Stage 18J-P11 - Bounded External Identity Load-Plan Artifact

Purpose: implement a bounded no-write artifact generator that proposes a
small, reviewable set of `station_external_identity` insert rows.

Scope:

- Add `apps/importer/src/station_external_identity_load_plan.py`.
- Reuse the Stage 18J-P9 read-only staged EDSM station matching path.
- Require explicit `--source-run-key` and `--max-rows`.
- Reject `--max-rows` values above `20` for the first bounded plan.
- Support optional `--source-file-key`, `--sample-limit`,
  `--input-candidate-artifact-sha256`, `--json`, and `--output`.
- Reject `--apply`, `--write`, `--write-staging`, `--load`, and `--commit`.
- Emit `station_external_identity_load_plan/v1` with `dry_run = true`,
  `read_only = true`, `report_only = true`, `canonical_writes_planned = 0`,
  `station_type_writes_planned = 0`, and `identity_rows_written = 0`.
- Plan only eligible `confirmed_candidate` rows, preserving
  `source_run_key`, `source_file_key`, and `source_record_hash`.
- Add synthetic tests for planned rows, skipped rejected/conflicting/proposed
  candidates, max-row guardrails, no-write SQL, deterministic JSON, and sample
  caps.

Non-goals:

- No production commands.
- No production DB access.
- No identity evidence load.
- No writes to `station_external_identity`.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p11-bounded-external-identity-load-plan-artifact.md`.

### Stage 18J-P-OPT - Identity Evidence Execution Board

Purpose: optimise the remaining external identity evidence workflow into
larger safe repo chunks while preserving tiny Hetzner production actions.

Scope:

- Add `stage-18j-p-identity-evidence-execution-board.md`.
- Record current state: `station_external_identity` exists, row count is `0`,
  read-only candidate artifact exists, bounded no-write load-plan exists, and
  the load plan saw `298177` candidates, `261938` eligible confirmed
  candidates, `20` planned rows, and `0` written rows.
- Define what must stay small: Hetzner operator actions, controlled loads,
  coverage generation, reconciliation generation, strict dry-run retry,
  approval packets, and apply.
- Define what can be bundled: tool, tests, operator script, docs, and roadmap
  updates when they share one safety boundary.
- Define Chunk A through Chunk E for the remaining Stage 18J-P identity work.
- Define the standard operator action shape: pre-check row counts, guarded
  script, artifact path, checksum, compact summary, post-check row counts, and
  explicit no-forbidden-actions confirmation.

Non-goals:

- No production commands.
- No production DB access.
- No identity evidence load.
- No writes to `station_external_identity`.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p-identity-evidence-execution-board.md`.

### Stage 18J-P12/P13 - Load-Plan Review + Planned Row Review Packet

Purpose: implement Chunk A from the identity evidence execution board by
recording the bounded load-plan review and adding offline planned-row review
packet tooling.

Scope:

- Record the reviewed `station_external_identity_load_plan/v1` operator
  artifact path, file checksum, internal integrity checksum, source run/file
  keys, candidate counts, and no-write result.
- Add `apps/importer/src/station_external_identity_review_packet.py`.
- Accept `--load-plan-artifact`, `--expected-load-plan-sha256`, `--output`,
  `--json`, and `--max-planned-rows`.
- Reject `--max-planned-rows` above `20`.
- Verify the source artifact file checksum before parsing.
- Parse only local JSON and accept no DSN.
- Reject write/apply/load/commit flags.
- Emit `station_external_identity_review_packet/v1`.
- Include capped planned rows and one manual review item per row, defaulting
  to `needs_manual_review`.
- Keep `canonical_writes_planned = 0`,
  `station_type_writes_planned = 0`, `identity_rows_written = 0`, and
  `approval_record_created = false`.
- Add `scripts/operator/archive/stage18j/stage18j_run_identity_review_packet.sh` as a
  Hetzner-only offline wrapper guarded by
  `scripts/operator/require_hetzner_operator_env.sh`.
- Add synthetic tests for checksum enforcement, missing artifacts, row caps,
  refusal flags, review defaults, safety fields, and deterministic JSON.

Non-goals:

- No production commands from Codex.
- No production DB access from Codex.
- No identity evidence load.
- No writes to `station_external_identity`.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p12-p13-load-plan-review-packet.md`.

### Stage 18J-P13A - Review Packet Contract Hardening

Purpose: fix the P12/P13 offline review packet contract so manual review items
are self-contained and human-reviewable.

Scope:

- Record that the first Hetzner offline review-packet run completed safely but
  had insufficient `manual_review_items` structure for row review.
- Keep `station_external_identity_review_packet/v1` as the packet schema.
- Embed the exact planned row inside each `manual_review_items` entry.
- Add a non-empty boolean `checks` object to each manual review item.
- Add `reviewer_notes = null`.
- Keep the top-level `planned_rows` list and require it to match embedded
  manual review rows exactly.
- Harden the operator wrapper summary so it validates and prints planned row
  count, manual review item count, and first-item planned-row/check presence.
- Add regression tests for embedded row/check fields, safety fields,
  deterministic JSON, checksum failures, max-row caps, write/load refusal, and
  no DSN acceptance.

Non-goals:

- No production commands from Codex.
- No production DB access from Codex.
- No identity evidence load.
- No writes to `station_external_identity`.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p12-p13-load-plan-review-packet.md`.

### Stage 18J-P14 - Controlled External Identity Load Tooling

Purpose: add controlled external identity load tooling and a dry-run execution
plan path while keeping production writes blocked in repo work.

Scope:

- Add `apps/importer/src/station_external_identity_loader.py`.
- Support `--dry-run` to validate a review packet and emit
  `station_external_identity_load_execution_plan/v1` without opening a DB
  connection or writing rows.
- Support `--write-reviewed` only with a separate
  `station_external_identity_load_approval_allowlist/v1` artifact and explicit
  confirmation flags.
- Require `--review-packet`, `--expected-review-packet-sha256`, `--dsn`,
  `--max-rows`, `--output`, and exactly one mode.
- Refuse `--max-rows > 20`.
- Refuse packets with bad schema, bad checksum, non-zero write counters,
  approval records, missing planned rows/checks, failed checks, non-confirmed
  identity status, non-null conflict reason, missing provenance, or missing
  external IDs.
- Reject import, reconciliation, summarizer, station-type dry-run, canonical
  apply, generic write, and commit flags.
- Add `scripts/operator/archive/stage18j/stage18j_run_identity_load_dry_run.sh` as a
  Hetzner-only dry-run wrapper guarded by
  `scripts/operator/require_hetzner_operator_env.sh`.
- Add synthetic tests for dry-run refusal modes, approval allowlist handling,
  fake-DB write-reviewed behavior, duplicate skip behavior, and deterministic
  JSON.

Non-goals:

- No production commands from Codex.
- No production DB access from Codex.
- No production identity evidence load.
- No production writes to `station_external_identity`.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No production approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p14-controlled-external-identity-load-tooling.md`.

### Stage 18J-P14B - Identity Load Dry-Run Review

Purpose: review the first controlled identity load dry-run before any identity
evidence write is approved.

Result:

- Reviewed `station_external_identity_load_execution_plan/v1`.
- Source review packet:
  `station_external_identity_review_packet_20260603T110848Z.json`.
- Review packet SHA-256:
  `8cf118d552e6bc35d23ab302d9e1020092385b372729dbb9b2bae5cd5f0758b6`.
- `identity_rows_selected = 20`.
- `identity_rows_written = 0`.
- `canonical_writes_planned = 0`.
- `station_type_writes_planned = 0`.
- `station_external_identity` row count remained `0`.
- Secret/path sanity check was clean.
- Hardened execution plans to emit `approval_record_created = false`.

Verdict:
`Ready only after approval allowlist artifact`.

Next gate:

- Create `station_external_identity_load_approval_allowlist/v1`.
- Tie it to the exact review packet SHA-256.
- Include exact approved review item IDs or plan row IDs.
- Keep it separate from canonical apply approval.

Non-goals:

- No production commands from Codex.
- No production DB access from Codex.
- No production identity evidence load.
- No production writes to `station_external_identity`.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No production approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p14b-identity-load-dry-run-review.md`.

### Stage 18J-P14C - Approval Allowlist Artifact

Purpose: add offline approval allowlist artifact tooling for the exact reviewed
external identity rows before any controlled write-reviewed load.

Scope:

- Add `apps/importer/src/station_external_identity_approval_allowlist.py`.
- Emit `station_external_identity_load_approval_allowlist/v1`.
- Verify the review packet SHA-256 exactly.
- Require explicit confirmation and
  `reviewer_decision = approve_selected_identity_rows`.
- Cap approved rows at `20`.
- Approve exact review item IDs and plan row IDs only.
- Include reviewer attestation for external identity evidence load scope only.
- Record `approval_record_created = false`.
- Record `identity_rows_written = 0`.
- Record `canonical_writes_planned = 0`.
- Record `station_type_writes_planned = 0`.
- Add `scripts/operator/archive/stage18j/stage18j_run_identity_approval_allowlist.sh` as a
  Hetzner-only offline wrapper.
- Add synthetic tests and docs/runbook updates.

Non-goals:

- No production commands from Codex.
- No production DB access from Codex.
- No production identity evidence load.
- No production writes to `station_external_identity`.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No production approval record.
- No Stage 18K work.

Support doc:
`stage-18j-p14c-approval-allowlist-artifact.md`.

### Stage 19A.1 - Operator Path Guardrails

Purpose: prevent Codex/local prompts from accidentally running Hetzner
production operator commands.

Scope:

- Add a reusable shell guard that checks the Hetzner host, `/opt/ed-finder`,
  Docker Compose availability, and required operator artifact directories.
- Add a Stage 18J compact-summary operator wrapper that calls the guard before
  reading production artifacts.
- Document Codex, DAVE2/local dev, and Hetzner production operator command
  contexts.
- Keep operator scripts fail-fast outside the production operator shell.

Non-goals:

- No production commands from Codex.
- No production DB access.
- No imports, reconciliation, production summarizer run, station-type dry-run,
  or canonical apply.
- No cron/scheduler wiring.
- No Stage 18J-P or Stage 18K work.

Support doc:
`../operations/operator-command-contexts.md`.

## Historical Docs Status

Older docs should not be deleted by default. They contain useful context, rationale, boundaries, and acceptance criteria. Treat them as historical/reference unless this file points to them as active.

| Doc | Status | Use |
|---|---|---|
| `stage-17a-colony-planner-intelligence-forward-plan.md` | Partly superseded | Source alignment and original trust/slot/picker roadmap. Do not follow its next-stage order blindly. |
| `stage-16-colony-role-model-plan.md` | Historical/reference | Role terminology, source separation, declared/inferred/observed boundaries. |
| `stage-15-planner-workspace-redesign-plan.md` | Historical/reference | Topology-first workspace rationale and UI architecture intent. |
| `simulation-preview-ui-architecture.md` | Historical/reference plus current architecture notes | Component ownership and delivered Stage 16/17 architecture notes. |
| `docs/ROADMAP.md` | Current roadmap | Single source for what happens next, including the supporting evidence and ingestion lane. |
| `docs/operations/enrichment-warehouse-runbook.md` | Active for enrichment/operator work | Guarded station enrichment, body/ring enrichment, warehouse run steps, and operator safety guidance. |
| Stage 5-14 docs | Historical/reference | Use only for the specific feature or regression they describe. |

## Final Recommendation

This file remains valuable as the Stage 17P planning baseline, but its old
"next sequence" list is now historical rather than the active control queue.

Current status after Stage 20 and the first Stage 21 execution pass:

1. Stage 17Q is complete.
2. Stage 17R/17S/17T/17U have been advanced substantially in code and tests and
   are now satisfied for the current planner baseline.
3. Stage 18A is complete.
4. Stage 18B/18C/18D/18E/18F/18G are already represented by the existing
   warehouse/report-only/admin groundwork and should not be described as
   untouched backlog.
5. Stage 18H and later remain historical follow-on work for the
   warehouse-to-planner and canonical-write planning track.
6. Stage 19 production activation remains separate deferred work.

Use `docs/ROADMAP.md` as the current control document and
`stage-21b-to-21f-stage17-stage18-burn-down.md` as the record of how the Stage
17 and Stage 18 backlog was burned down or reclassified. Historical follow-on
roadmaps remain available in `docs/colonisation-redesign/stage-22-roadmap.md`
and `docs/colonisation-redesign/stage-23-roadmap.md`. The first live selected
system evidence checkpoint is recorded in
`docs/colonisation-redesign/stage-23a-first-live-per-system-evidence-provider.md`.
30. Stage 18J-P-filter strict station-type dry-run filter hardening.
31. Stage 18J-P-dryrun-ops operator-safe station-type dry-run wrapper.
32. Stage 18J-P2 station-type identity coverage diagnostics.
33. Stage 18J-P3 canonical external station identity model.
34. Stage 18J-P4 external station identity schema design.
35. Stage 18J-P5 external station identity migration draft, not applied to production.
36. Stage 18J-P6 external identity migration production readiness review.
37. Stage 18J-P7 external identity schema production apply closeout.
38. Stage 18J-P8 external identity evidence loader/reconciliation design.
39. Stage 18J-P9 read-only external identity candidate artifact.
40. Stage 18J-P10 external identity candidate artifact review.
41. Stage 18J-P11 bounded external identity load-plan artifact, no DB writes.
42. Stage 18J-P-OPT identity evidence execution board.
43. Stage 18J-P12/P13 load-plan review packet, no DB writes.
44. Stage 18J-P13A review packet contract hardening, no DB writes.
45. Stage 18J-P14 controlled identity load tooling and dry-run plan.
46. Stage 18J-P14B identity load dry-run review.
47. Stage 18J-P14C approval allowlist artifact for selected identity rows.
48. Stage 18J-P14D controlled write-reviewed identity load.
49. Chunk C: Stage 18J-P15 post-load identity coverage.
50. Chunk D: Stage 18J-P16 reconciliation integration with confirmed identity.
51. Chunk E: Stage 18J-P17 retry strict station-type dry-run.

This keeps ED-Finder moving toward a genuinely intelligent colony planner while protecting the trust boundaries that make the tool useful. The warehouse should become observable, explainable, and storage-isolated before it becomes a canonical write source.


