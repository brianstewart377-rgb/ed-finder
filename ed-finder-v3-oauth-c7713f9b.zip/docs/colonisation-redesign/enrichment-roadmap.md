# EDSM station enrichment — production roadmap & runbook

> **Audience:** anyone running the guarded EDSM station enrichment on the
> Hetzner production host (or a staging clone), or extending the importer/guard
> code in this repo.
>
> **Scope:** the apply path that writes verified `stations.station_type`,
> `stations.distance_from_star`, `stations.body_name`, and confirmed
> `station_body_links` rows from EDSM. Ring enrichment lives in the same
> importer entrypoint but follows a separate Spansh-first contract.

This file is the source of truth for how we run station enrichment safely at
scale. If a procedural step in this document conflicts with what you see in
the code, the code wins — please update this doc in the same PR.

---

## 1. Components

| Path | Role |
|---|---|
| `apps/importer/src/enrich_system_data.py` | Importer entrypoint. Implements the dry-run / metadata-apply / confirmed-link-apply contract per system. Emits a single JSON report on stdout, progress on stderr, and writes the database via `apps/importer/src/edsm_station_enrichment_probe.py`. |
| `apps/importer/src/edsm_station_enrichment_probe.py` | The actual EDSM HTTP client + change planner. Owns identity matching, conflict classification, the trust-and-hold rules for `distance_from_star`, and the rate-limit retry loop. |
| `scripts/station_enrichment_guard.py` | Production wrapper. Runs the importer in a docker-compose `importer` service, validates each phase JSON, gates apply behind safety analysis, writes per-batch artifacts, and maintains the resumable all-records checkpoint. **Never** call the importer directly in production — use the guard. |
| `scripts/run_station_enrichment_guarded.sh` | One-line shell shim around the guard so cron/Hetzner systemd timers can invoke it without remembering the python path. |
| `scripts/station_enrichment_status.py` | Read-only status helper. Inspects the latest run output dir and the checkpoint without touching EDSM or the database. |
| `tests/test_edsm_station_enrichment_probe.py` | Importer-level unit tests (no live EDSM). |
| `tests/test_station_enrichment_guard.py` | Guard-level unit tests with fake command runners (no docker, no live EDSM). |
| `tests/test_station_enrichment_status.py` | Status helper unit tests. |

---

## 2. Safety invariants the guard upholds

These are **hard contracts**. If any of them looks wrong in a live run, stop
the run and report it before re-running.

1. **Single source of truth.** Trusted writes always carry
   `source = "edsm_system_api"` and
   `confidence = "exact_station_identity"`. Anything weaker is a bug.
2. **Identity gate.** A station must match by EDSM id/marketId AND name before
   any column is updated.
3. **Trust-and-hold for `distance_from_star`.** Once a station's distance is
   already at trusted EDSM/exact provenance we **never** replan a distance
   update, even when the live EDSM value drifts. Orbital stations show
   natural `distanceToArrival` jitter between EDSM refreshes; replanning would
   re-touch the column on every nightly run. Population (NULL → value) and
   replacement of untrusted legacy distances still happen.
4. **Permanent station types only.** `Unknown` may be promoted to a known
   permanent type (Orbis, Coriolis, Asteroid Base, …). Carriers and other
   transient stations are ignored — never written.
5. **Risky conflicts block apply.** `id_name_mismatch`,
   `known_station_type_mismatch`, `station_economy_mismatch` and any
   `*_unsafe` write-safety marker abort the apply phase. The guard refuses to
   continue.
6. **Final dry-run validates writes.** When the guard applied any metadata or
   confirmed-link write it reruns a final dry-run and asserts that
   `metadata_updates_planned == 0` and `confirmed_link_updates_planned == 0`.
   No-op batches skip this re-fetch (see §4).
7. **Success-only checkpointing.** Only systems that returned a non-failed
   station report are appended to the resumable checkpoint. Systems that
   tripped a fetch / rate-limit error are deliberately left off the
   checkpoint so a later batch retries them.

---

## 3. Resumable checkpoint contract

Long `--all-records` runs are batched (default `--batch-size 2000`). Each
batch is a full guarded sequence (`initial dry-run → metadata applies →
confirmed-link apply → final dry-run`) restricted to the next batch of
systems that are not yet on the checkpoint.

### Default checkpoint path

If `--checkpoint-file` is **not** provided, the guard uses

```
/tmp/edfinder-station-enrichment/all-records-station-enrichment-checkpoint.json
```

This path is stable across runs by design: a second invocation resumes from
the first one's checkpoint instead of starting from scratch. The guard prints
the resolved checkpoint path at run start so the operator can verify it. To
override this for staged production runs, pass `--checkpoint-file
/path/to/your-state.json`.

### What goes into the checkpoint

```json
{
  "processed_system_id64s": [<sorted, deduplicated successful ids>],
  "last_system_id64": <max of the above>
}
```

The guard **only** appends to `processed_system_id64s` when the batch's
guarded sequence finishes cleanly **and** the system did not appear under
`stations.systems_fetch_failed` / `stations.fetch_errors`. Failed systems are
left for the next batch.

### Failure handling

* If a batch contains some failed systems and some successful ones, the
  successful ones are checkpointed and the run continues with the next batch.
  The failed system ids will reappear in the next batch's eligible set
  because they are still missing trusted provenance.
* If **every** system in a batch fails (typical EDSM outage / rate-limit
  storm), the guard logs a clear "all-records aborted" message and exits.
  The checkpoint stays exactly as it was so the next run resumes from the
  same point. **Do not** delete the checkpoint to "force a retry"; that would
  redo every previously-processed system.

---

## 4. No-op batch handling

If the initial dry-run for a batch reports zero metadata updates and zero
confirmed-link updates, the guard treats the batch as a clean no-op:

* No metadata apply runs.
* No confirmed-link apply runs.
* **No final dry-run is re-fetched.** A second EDSM round-trip on a clean
  batch costs rate-limit budget and risks reintroducing spurious live deltas
  (notably `distanceToArrival` jitter for orbiting stations).
* The batch's successful system ids are still checkpointed.

When a metadata or confirmed-link apply *did* run in the batch, the final
dry-run re-fetch is unconditional and its zero-plan assertion is the
acceptance test for the writes.

---

## 5. EDSM rate-limit handling

The probe enforces a layered defence:

1. **Per-request retry budget** — `--edsm-retries` (default 3) attempts per
   endpoint. Non-429 errors use the exponential `--edsm-retry-backoff-seconds`
   ladder.
2. **Retry-After floor** — when EDSM returns a 429 with a Retry-After header
   we honour it but clamp it to `EDSM_MIN_RETRY_AFTER_SECONDS` (default
   **5 seconds**). EDSM occasionally answers with very short Retry-Afters
   (1–2 s); obeying them literally guarantees another 429 on the next call.
3. **Configured backoff floor** — when no Retry-After header is present the
   probe falls back to `--edsm-429-backoff-seconds` ×
   `--edsm-429-backoff-multiplier^attempt`, then clamps the result up to the
   same 5 s floor.
4. **Repeated-429 escalation** — the guard mirrors importer stderr live and
   counts consecutive rate-limit log lines per phase. After 3 in a row it
   prints a one-shot warning recommending a higher
   `--edsm-429-backoff-seconds` / `--edsm-request-delay-seconds`, or aborting
   and resuming later. The checkpoint is preserved either way.

If you see the warning more than once per run, **abort and let EDSM cool
down** rather than turning up the dials further; we are part of a wider EDSM
load-shedding window in that case.

---

## 6. Observability

While a run is in flight the guard now streams importer stderr live to its
own stderr, line-by-line, so the operator can watch per-system progress in
real time. Each batch persists:

* `01_initial_dryrun.json[.stderr.txt]`
* `02_metadata_apply_*.json[.stderr.txt]` (if any apply ran)
* `03_after_metadata_*_dryrun.json[.stderr.txt]`
* `04_confirmed_links_apply.json[.stderr.txt]` (if any apply ran)
* `final_dryrun.json[.stderr.txt]` (skipped on no-op batches)

The guard prints a compact summary line per phase with the counters spec
asked for:

```
initial dry-run: systems_processed=N metadata_updates=M confirmed_links=L
                 conflicts=C skipped=S fetch_errors=F systems_fetch_failed=K
                 suppressed_station_writes=W ignored_transient_non_slot=I
                 dirty_marked/planned=D/P file=...
```

To inspect run state from a separate shell (or to feed into nagios/an
operator dashboard) use `scripts/station_enrichment_status.py`:

```sh
# Default: stable all-records checkpoint, default output root.
python3 scripts/station_enrichment_status.py

# Ask whether a specific system has already reached the checkpoint.
python3 scripts/station_enrichment_status.py --system-id64 9472415114065

# Machine-readable for cron/email.
python3 scripts/station_enrichment_status.py --json
```

---

## 7. Hetzner production runbook

Run from the host as the deploy user, with the docker-compose `import`
profile already provisioned (the guard executes
`docker compose --profile import run --rm -T importer ...` for every phase).

### 7.1 Smoke check (always do this first)

```sh
cd /opt/ed-finder
# Process at most 2 systems, never apply. Confirms the importer + guard pipeline
# and the EDSM connectivity path without touching the database.
python3 scripts/station_enrichment_guard.py --limit 2 --dry-run-only
```

Expect: a fresh dir under `/tmp/edfinder-station-enrichment/`, an
`01_initial_dryrun.json`, a `final_dryrun.json` if any apply ran (it won't,
because of `--dry-run-only`), and a one-line summary per phase. No errors on
stderr.

### 7.2 Bounded apply

```sh
cd /opt/ed-finder
# Apply on a small slice. If anything goes wrong only N stations are touched.
python3 scripts/station_enrichment_guard.py --limit 100 --yes
```

Inspect:
* Last `final_dryrun.json` should have `metadata_updates_planned == 0` and
  `confirmed_link_updates_planned == 0`.
* `summary.stations.fetch_errors` and `summary.stations.systems_fetch_failed`
  are 0 on a healthy run.

### 7.3 Resumable all-records run

```sh
cd /opt/ed-finder
nohup python3 scripts/station_enrichment_guard.py \
    --all-records \
    --batch-size 2000 \
    --max-batches 50 \
    > /var/log/edfinder/station-enrichment.$(date -u +%Y%m%dT%H%M%SZ).log 2>&1 &
```

Notes:
* No `--checkpoint-file` is needed: the guard uses the stable default at
  `/tmp/edfinder-station-enrichment/all-records-station-enrichment-checkpoint.json`.
  If you want the checkpoint to survive `/tmp` cleanup across reboots, point
  at a path under `/var/lib/edfinder/state/` instead.
* `--max-batches` keeps any single shell session bounded; re-running with the
  same default checkpoint resumes where the previous session stopped.
* Use `tail -f` on the log file (or
  `python3 scripts/station_enrichment_status.py --json --output-root
  /tmp/edfinder-station-enrichment`) for live progress.

### 7.4 Healthy-day rate-limit knobs

For a quiet EDSM window the defaults are appropriate. When EDSM is hot you
can either:

```sh
# Slow the request cadence and increase the no-Retry-After backoff.
python3 scripts/station_enrichment_guard.py --all-records \
    --edsm-request-delay-seconds 1.5 \
    --edsm-429-backoff-seconds 120
```

…or pause the run, wait, and restart — the checkpoint is preserved either
way.

### 7.5 What to do on the warnings the guard prints

| Guard message | Operator action |
|---|---|
| `[guard] EDSM 429 observed N times in this phase; consider raising --edsm-429-backoff-seconds…` | If first time in a run: keep going, the backoff floor will absorb it. If repeated: abort, raise the delays, restart later. |
| `all-records batch X: skipping checkpoint append for systems_fetch_failed=N` | Expected when EDSM blips. Those systems will be retried in the next batch. |
| `all-records aborted: every system in this batch hit a fetch/rate-limit error` | EDSM is degraded. Stop the run, investigate, retry later. The checkpoint stays accurate. |
| `Guard failed: ... blocked by safety gate` | Safety net tripped. Inspect the most recent `*_dryrun.json` for `conflicts` and `metadata_updates_planned`. **Do not** force-apply by editing the JSON. |

### 7.6 Recovery from a partial / interrupted run

The guard never deletes the checkpoint. If you `Ctrl+C` mid-batch the
already-completed batches are recorded; the in-flight batch is lost (its JSON
files remain on disk for inspection but no rows from it were checkpointed
unless they were applied successfully before the interruption). Re-run with
the same arguments and the next batch resumes from the next un-processed
system id64.

---

## 8. Body/Ring Enrichment Input Strategy

Body/ring enrichment should be planned around explicit input modes. The
planner must remain pure: it receives local body/ring rows and external
source rows, then returns a `body_ring_enrichment_dry_run/v1` report. The
planner must not perform network access and must not write to the database.

### 8.1 Input modes

| Input mode | Best use | Limits / cautions |
|---|---|---|
| JSON fixtures / offline samples | Unit tests, deterministic examples, trust-classification edge cases, and CI. | Fixtures are not enough to prove SQL joins, schema compatibility, null/enum behaviour under real database adapters, or production-scale performance. |
| Non-production DB | Integration testing against the real schema, joins, null handling, enum handling, and migrations. | Safer than production, but slower and more complex than fixtures. It should still use offline source data, not live enrichment APIs. |
| Existing local production tables | Production dry-runs using the real local source of truth. Required for galaxy-scale validation because it exercises the actual body/ring population and current trust state. | Must remain read-only in this warehouse path. Use only for dry-run reads and report generation. |
| Offline snapshots / staging data | Preferred external source for large-scale enrichment and repeatable validation. | Needs a parser/normaliser and versioned snapshot handling, but gives stable inputs, batchability, and rerunnable reports. |
| Live APIs | Small manual diagnostics only, if ever needed outside this planner contract. | Avoid for large all-record enrichment: rate limits, latency, upstream volatility, and poor repeatability make them unsuitable for deterministic galaxy-scale planning. |

### 8.2 Scalable architecture

The long-term architecture should be:

```text
external snapshot/file
-> source parser/normaliser
-> staging model or in-memory source rows
-> read-only local DB fetch
-> pure planner
-> versioned dry-run report
-> separately designed write path only if explicitly approved later
```

For production scale, the preferred path is existing local tables plus
offline source snapshots plus checkpointed batching. That lets us validate
the real galaxy-sized local dataset without coupling the dry-run to live API
availability or upstream drift.

For development and testing, the robust path is JSON fixtures plus
non-production DB integration tests plus production read-only dry-runs.
Fixtures keep planner behaviour deterministic; the non-production DB proves
schema and join compatibility; production read-only dry-runs prove scale and
real-data classification without modifying rows.

### 8.3 Staged implementation

1. **Stage A: JSON fixture CLI mode.** Accept fixture files and emit
   `body_ring_enrichment_dry_run/v1` with no database or network dependency.
2. **Stage B: read-only non-production DB mode.** Fetch local rows from a
   staging/test database and combine them with offline source rows to prove
   joins, migrations, null handling, and enum handling.
3. **Stage C: production read-only dry-run.** Read existing local production
   tables and offline snapshots only, use checkpointed batching for scale, and
   write versioned reports without touching production data.
4. **Stage D: future write-path design review.** Keep this out of the current
   warehouse implementation. Any canonical writes need a separate proposal,
   safety review, and test plan after dry-run reports are boring and
   predictable.

### 8.4 Body/ring trust model

The body/ring planner must preserve the current trust distinction:

* Source-only `body_scan_facts.is_ringed = True` remains unknown until it is
  resolved to trusted local `body_rings` rows.
* Source-only `False` may represent explicit trusted no-rings according to the
  existing tests.
* Trusted local-matched `body_rings` rows are required before promoting a body
  to confirmed ringed state.

## 8.5 Offline enrichment warehouse foundation

The first warehouse foundation is documented in
`docs/colonisation-redesign/enrichment-staging-architecture.md` and implemented
by:

| Path | Role |
|---|---|
| `sql/026_enrichment_staging_foundation.sql` | Additive source-run, raw-record, normalised staging, and derived dry-run intelligence tables. |
| `apps/importer/src/enrichment_staging.py` | Pure canonicalisation, hashing, source classification, validation, and report skeleton helpers. |
| `apps/importer/src/enrichment_snapshot_loader.py` | Offline-only local JSON/JSON.GZ loader for EDSM station and body/ring snapshot-style records. |
| `apps/importer/src/enrichment_staging_db_loader.py` | Explicitly gated staging-only DB loader, schema preflight, staged-row reports, and read-only reconciliation CLI. |
| `apps/importer/src/enrichment_warehouse.py` / `apps/importer/src/enrichment_warehouse_repository.py` | Warehouse boundary, SQL safety checks, and repository-backed access to warehouse tables. |
| `apps/importer/src/enrichment_write_plans.py` | Pure staging write-plan builders used before DB execution. |
| `apps/importer/src/enrichment_reconciliation.py` / `apps/importer/src/enrichment_reconciliation_scoring.py` | Read-only candidate shaping and report-only confidence/risk scoring. |
| `apps/importer/src/enrichment_analytics.py` | Pure report-only analytics, colonisation, and mission-density signal scaffolds. |
| `tests/fixtures/edsm_station_snapshot.json` | Tiny deterministic EDSM station snapshot fixture. |
| `tests/fixtures/edsm_body_ring_snapshot.json` | Tiny deterministic EDSM body/ring snapshot fixture. |
| `tests/test_enrichment_staging.py` / `tests/test_enrichment_snapshot_loader.py` | Fixture-backed tests for hashes, source classes, report versions, JSON/GZIP loading, source metadata, skipped rows, duplicates, unsupported shapes, and deterministic output. |

This warehouse path is deliberately not wired into any operations job. It does
not call EDSM, invoke Docker, connect to production Postgres, run migrations,
update canonical station/body/system rows, or create station-body links. The
default mode emits `enrichment_snapshot_load_plan/v1` dry-run reports only.
Staging DB writes are opt-in and require `--write-staging`, `--dsn`, and
`--confirm-staging-db`; they target only the enrichment warehouse tables.

Run the local fixture loader from the repo root:

```sh
python3 apps/importer/src/enrichment_snapshot_loader.py \
    --source edsm_nightly_stations \
    --source-file tests/fixtures/edsm_station_snapshot.json \
    --json
```

Use `--limit N` for bounded inspection of larger local snapshots. `--dry-run`
is the default. `--apply`, `--write`, and `--commit` fail closed.

The current warehouse also supports local body/ring snapshots through
`--source edsm_nightly_bodies`, read-only reconciliation via
`--report-reconciliation`, staged-row summaries via `--report-staged-run`, and
pure report-only analytics/signals. Optional real-Postgres smoke tests for the
staging loaders and reconciliation are skipped by default unless
`EDFINDER_STAGING_TEST_DSN` and `EDFINDER_CONFIRM_STAGING_TEST_DB=yes` are set.

Stage 18D keeps this path report-only while making snapshot inputs more
explainable: reports expose source format/version, record stream shape,
source timestamp/freshness summaries, skipped-row reason distributions,
duplicate source-record hashes, report-only source-identity conflicts, and
body/ring ring-array evidence. Missing ring arrays remain unknown, source-only
ring evidence remains source-only, and future nested body source shapes are
reported as unsupported until a dedicated adapter exists.

Stage 18E adds a versioned `warehouse_coverage_report` section to read-only
reconciliation output. It is for operator review of evidence completeness:
station coverage by system, missing station evidence where body/ring evidence
exists, trusted versus unknown ring evidence, explicit trusted no-ring scan
evidence, confirmed/inferred/unresolved station-body links, stale or undated
source evidence, skipped/malformed source rows, duplicate source-record hashes,
source identity conflicts, high-value systems needing better evidence, and
source type/source-format coverage. It remains dry-run/report-only and does
not promote source-only evidence to canonical truth.

Stage 18F hardens reconciliation confidence as a versioned, report-only model.
Candidates now carry deterministic confidence levels, reason codes, source
freshness impact, risk classes, review classifications, and future canonical
review markers that explicitly disable auto-promotion. These labels explain
confirmed, inferred/verify, unresolved, source-only, stale, volatile, blocked,
report-only, and unknown states for operator review only; they do not change
planner scoring, canonical write eligibility, or any production job wiring.

Stage 18G exposes warehouse run and evidence status in the token-gated Admin
surface. The API reads only a configured, prepublished JSON artifact and
returns sanitized counts for latest snapshot/reconciliation state, source
coverage, unresolved/risky/blocked/stale evidence, skipped or duplicate source
records, and canonical-safety flags. Missing or invalid artifacts remain
unavailable/unknown; the panel does not run warehouse scripts, query the
warehouse, call live APIs, or add write controls.

Stage 18H adds a read-only warehouse-to-planner evidence bridge. It lets the
Colony Planner present selected warehouse/report-only evidence as evidence, not
truth. Because the Stage 18G warehouse artifact is admin-token-gated and
aggregate-only (it carries review counts, not per-`system_id64` rows), there is
no safe key to link warehouse evidence to a planner system yet. Per the stage
decision gate, Stage 18H ships the conservative path: a typed read-only
`PlannerWarehouseEvidence` model, a compact source-labelled planner card that
defaults to a safe unavailable/unknown state, tests proving the unavailable
state and no-mutation guarantee, and a design doc with the future per-system
integration path
(`docs/colonisation-redesign/stage-18h-warehouse-planner-evidence-bridge.md`).
It adds no backend endpoint, makes no live calls, and never mutates planner,
Build Plan, role, observed-evidence, validation, scoring, Preview, optimiser, or
canonical state.

Stage 18I documents the canonical-write design review without implementing any
write path. It defines future candidate write paths, evidence-only and banned
paths, source/confidence requirements, audit and rollback requirements,
operator approval, table risks, safety blocks, and required tests. Its
conclusion is conservative: no canonical writes are authorized, Stage 18I.5
must decide the warehouse database boundary first, and any Stage 18J pilot
should start with exact station type promotion only. See
[`stage-18i-canonical-write-design-review.md`](./stage-18i-canonical-write-design-review.md).

Stage 18I.5 documents the warehouse database boundary decision without
implementing it. It recommends a separate `edfinder_enrichment` database on the
same Postgres stack if feasible, preserves a future path to a separate Postgres
instance, defines role/permission boundaries, snapshot/read-only comparison,
write-plan transfer, audit ownership, retention, and Stage 18J readiness
criteria. See
[`stage-18i5-warehouse-database-boundary-review.md`](./stage-18i5-warehouse-database-boundary-review.md).

Stage 18T hardens the canonical safety test environment for Stage 18J-class
work. It adds a dedicated CI job, explicit test prerequisites, a one-command
local runner, and disposable Postgres rehearsal/permission-boundary coverage
for the guarded station type pilot. It does not authorize production apply,
artifact approval, production DB access, or wider canonical backfill. See
[`stage-18t-canonical-safety-test-environment.md`](./stage-18t-canonical-safety-test-environment.md).

Stage 18J-Q documents the missing production reconciliation artifact
prerequisite for Stage 18J-P. It searches local/configured artifact locations,
defines the required `enrichment_staging_reconciliation/v1` contract, documents
the read-only report generation path, and keeps Stage 18J-P blocked until a
verified report-only production artifact exists. See
[`stage-18j-q-production-reconciliation-artifact-readiness.md`](./stage-18j-q-production-reconciliation-artifact-readiness.md).

Stage 18J-Q2 documents the exact later operator plan for generating that
artifact without running production reconciliation in the planning stage. It
defines the `--report-reconciliation` command, required inputs, read-only DSN
proof, output handling, stop conditions, and Stage 18J-P readiness criteria.
See
[`stage-18j-q2-readonly-production-reconciliation-plan.md`](./stage-18j-q2-readonly-production-reconciliation-plan.md).

Stage 18J-Q3 attempted to move from plan to artifact generation, but the
pre-run gate failed before any production-connected command because the
verified read-only DSN, approved source run/file, read-only session option, and
operator-managed output path were not available. Stage 18J-P remains blocked.
See
[`stage-18j-q3-readonly-production-reconciliation-artifact.md`](./stage-18j-q3-readonly-production-reconciliation-artifact.md).

Stage 18J-Q5 added support for the nested EDSM system station snapshot shape
observed on the production server. It extracts deterministic station staging
rows from nested `stations` arrays while preserving parent system raw records
and keeping nested `bodies` collections as warning evidence only. See
[`stage-18j-q5-nested-edsm-station-snapshot-support.md`](./stage-18j-q5-nested-edsm-station-snapshot-support.md).

Stage 18J-Q6 follows the failed full warehouse station staging load attempt.
It makes explicit station write-staging memory-safe by streaming source-record
batches and emitting a compact write summary rather than retaining all raw and
staged rows in memory. After Q6 merges, the next server action is a controlled
retry of the warehouse station staging load. If that succeeds, move to
read-only reconciliation artifact generation. Stage 18J-P remains blocked
until a valid reconciliation artifact exists. Stage 19 should expand the
warehouse broadly and design freshness/scheduler support, but no cron/scheduler
implementation is allowed in Q6. See
[`stage-18j-q6-memory-safe-warehouse-station-load.md`](./stage-18j-q6-memory-safe-warehouse-station-load.md).

Stage 18J-Q7 fixes the next read-only artifact blocker. After the successful
Q6 staging load, reconciliation report generation failed while printing JSON
because DB-native datetime values were not serializable. The artifact file was
0 bytes and canonical data remained unchanged. Q7 makes
`enrichment_staging_reconciliation/v1` output JSON-safe and deterministic
before retrying Stage 18J-Q3. Stage 18J-P remains blocked until a valid
reconciliation artifact exists. See
[`stage-18j-q7-reconciliation-json-serialization-fix.md`](./stage-18j-q7-reconciliation-json-serialization-fix.md).

Stage 18J-Q8 adds an offline compact summary tool for very large
`enrichment_staging_reconciliation/v1` artifacts. It streams an existing JSON
artifact without DB access, records the source basename, file size, SHA-256,
schema, candidate counts, update/insert counts, blocking reasons,
confidence/risk counts, coverage counts, and capped sanitized candidate
samples. It does not run production reconciliation, station-type dry-run,
canonical apply, or Stage 18J-P/18K work. Stage 18J-P remains blocked until a
compact review output exists and has been reviewed. See
[`stage-18j-q8-compact-reconciliation-summary.md`](./stage-18j-q8-compact-reconciliation-summary.md).

Stage 18J-Q9 reviews the compact summary counts and records the station-type
dry-run readiness verdict. The compact summary is valid and useful, but the
unfiltered reconciliation scope is too broad: `298177` station candidates,
`163722` station candidate updates, `35340` source-only missing-canonical
candidates, `258` ambiguous matches, and all `298177` station/body association
candidates blocked by missing station body names. The verdict is
`Ready only with strict filter`; Stage 18J-P remains blocked until the
station-type dry-run scope is explicitly filtered to externally proven,
non-ambiguous, non-volatile, permanent station-type candidates with an explicit
max-row bound. See
[`stage-18j-q9-compact-summary-review-station-type-dry-run-readiness.md`](./stage-18j-q9-compact-summary-review-station-type-dry-run-readiness.md).

Stage 18J-P-filter hardens the station-type dry-run filter before any
production dry-run retry. The pilot now requires external station identity via
matching `market_id` or matching `edsm_station_id`, rejects internal
primary-key-only identity proof, excludes ambiguous/source-only/volatile/
transient/non-station-type candidates, keeps missing `station_body_name` as a
station/body-link blocker only, requires an explicit max-row bound, records the
input reconciliation artifact checksum, and keeps dry-run
`canonical_writes_planned = 0`. It does not run Stage 18J-P or authorize apply.
See
[`stage-18j-p-filter-strict-station-type-dry-run-filter.md`](./stage-18j-p-filter-strict-station-type-dry-run-filter.md).

Stage 18J-P-dryrun-ops adds the Hetzner-only wrapper for the future strict
station-type dry-run. The wrapper verifies the validated reconciliation
artifact SHA-256, requires bounded `MAX_ROWS` and refuses values above `20`,
passes compact blocked-candidate output options, writes the dry-run artifact
under the operator artifact directory, and prints compact summary fields. It
does not run from Codex, touch the DB, create approvals, or run apply. See
[`stage-18j-p-dryrun-operator-safe-wrapper.md`](./stage-18j-p-dryrun-operator-safe-wrapper.md).

Stage 18J-P2 adds identity coverage diagnostics after the first bounded
Hetzner/operator station-type dry-run safely produced zero eligible candidates.
The dry-run artifact now records compact counts for source/canonical
`market_id`, `edsm_station_id`, `system_id64`, station-name, canonical match
count, and possible missing canonical external IDs in the reconciliation
payload. The strict filter is unchanged, `canonical_writes_planned` stays `0`,
and the next operator action is diagnostic rerun only. See
[`stage-18j-p2-station-type-identity-coverage-diagnostics.md`](./stage-18j-p2-station-type-identity-coverage-diagnostics.md).

Stage 18J-P3 records the external station identity model investigation. It
confirms that canonical `stations` has no `market_id` or `edsm_station_id`,
that `s.id AS market_id` is a compatibility alias/update target rather than
external identity proof, and that `station_body_links.market_id` is scoped to
station/body association evidence. The recommendation is a separate
provenance-backed `station_external_identity` table, not relaxed station-type
filtering. See
[`stage-18j-p3-canonical-external-station-identity-model.md`](./stage-18j-p3-canonical-external-station-identity-model.md).

Stage 18J-P4 designs the external station identity schema. The preferred model
keeps identity rows separate from `stations`, preserves source run/file/hash
provenance, tracks confidence/freshness/status, blocks conflicting evidence,
and allows only `identity_status = 'confirmed'` rows to prove canonical
external station identity in read-only reconciliation. It does not add a SQL
migration, run production commands, run imports, run reconciliation, run
station-type dry-run, or authorize apply. See
[`stage-18j-p4-external-station-identity-schema-design.md`](./stage-18j-p4-external-station-identity-schema-design.md).

Stage 18J-P5 drafts the additive external identity migration in
`sql/027_station_external_identity.sql` and adds synthetic migration contract
tests. The migration creates `station_external_identity`, requires at least one
external ID, constrains identity statuses, preserves source run/file/hash
provenance, adds partial unique indexes for confirmed identities, and adds
lookup indexes for station, system, external IDs, source run/file, and status.
It is not applied to production, does not update `stations`, does not backfill
identity rows, and does not authorize station-type dry-run or apply. See
[`stage-18j-p5-external-station-identity-migration-draft.md`](./stage-18j-p5-external-station-identity-migration-draft.md).

Stage 18J-P6 reviews the P5 migration for production readiness. The verdict is
`Ready for schema-only production application`, limited to a later Hetzner
operator stage that creates the empty table and indexes only. P6 defines
required preflight checks, post-apply checks, rollback expectations, and
forbidden follow-on actions. It does not apply the migration, touch production
DB, load identity evidence, run reconciliation, run station-type dry-run, or
authorize apply. See
[`stage-18j-p6-external-identity-migration-production-readiness.md`](./stage-18j-p6-external-identity-migration-production-readiness.md).

Stage 18J-P7 records the schema-only production application closeout for
`sql/027_station_external_identity.sql`. The `station_external_identity` table
now exists on Hetzner with the expected constraints and indexes, has row count
`0`, and the recorded canonical `stations` count stayed unchanged at `284763`. No
identity evidence was loaded, no reconciliation/import/summarizer/station-type
dry-run/apply was run, and no station-type data changed. See
[`stage-18j-p7-external-identity-schema-production-apply-closeout.md`](./stage-18j-p7-external-identity-schema-production-apply-closeout.md).

Stage 18J-P8 designs the external identity evidence loader/reconciliation
workflow. It selects existing `edsm_nightly_stations` warehouse rows as the
first evidence source, maps `staging_edsm_stations` fields to
`station_external_identity`, defines read-only candidate matching/status rules,
and requires a dry-run identity candidate artifact before any identity evidence
load. It keeps station-type writes blocked and does not run production
commands, load identity evidence, run reconciliation, run station-type dry-run,
or run apply. See
[`stage-18j-p8-external-identity-evidence-loader-reconciliation-design.md`](./stage-18j-p8-external-identity-evidence-loader-reconciliation-design.md).

Stage 18J-P9 adds the read-only external identity candidate artifact generator
in `apps/importer/src/station_external_identity_candidates.py`. It reads staged
EDSM station evidence through an explicit read-only DSN, matches by
`system_id64` plus normalized station name, preserves source run/file/hash
provenance, emits compact deterministic JSON with capped samples and integrity
hash, and writes no identity or canonical rows. See
[`stage-18j-p9-readonly-external-identity-candidate-artifact.md`](./stage-18j-p9-readonly-external-identity-candidate-artifact.md).

Stage 18J-P10 reviews the first Hetzner read-only external identity candidate
artifact. The artifact inspected `298177` staged EDSM station rows and reported
`261938` `confirmed_candidate` rows, `258` conflicting rows, and `35981`
rejected/source-only rows with no identity or canonical writes. The verdict is
`Ready only for bounded identity load dry-run`: candidates are promising, but
the next step must be a bounded no-write load-plan artifact before any insert
into `station_external_identity`. See
[`stage-18j-p10-external-identity-candidate-artifact-review.md`](./stage-18j-p10-external-identity-candidate-artifact-review.md).

Stage 18J-P11 adds the bounded no-write external identity load-plan artifact
generator in `apps/importer/src/station_external_identity_load_plan.py`. It
reads staged EDSM station evidence through the same read-only matching path,
requires explicit source filters and `--max-rows`, rejects bounds above `20`,
plans only eligible `confirmed_candidate` rows, preserves provenance, rejects
write/apply/load flags, and keeps `identity_rows_written = 0`. See
[`stage-18j-p11-bounded-external-identity-load-plan-artifact.md`](./stage-18j-p11-bounded-external-identity-load-plan-artifact.md).

Stage 18J-P-OPT adds the identity evidence execution board. It keeps Hetzner
production actions tiny and single-purpose while bundling repo work into larger
safe chunks that include tooling, tests, operator scripts, docs, and roadmap
updates where appropriate. It tracks Chunk A P12/P13 review pack, Chunk B P14
controlled identity load tooling, Chunk C P15 post-load identity coverage,
Chunk D P16 read-only reconciliation integration, and Chunk E P17 strict
station-type dry-run retry. See
[`stage-18j-p-identity-evidence-execution-board.md`](./stage-18j-p-identity-evidence-execution-board.md).

Stage 18J-P12/P13 implements Chunk A from that board. It records the bounded
load-plan artifact review and adds the offline planned-row review packet
generator in `apps/importer/src/station_external_identity_review_packet.py`,
plus a Hetzner-only wrapper in
`scripts/operator/archive/stage18j/stage18j_run_identity_review_packet.sh`. The packet tool
verifies the exact load-plan artifact SHA-256, reads only local JSON, accepts
no DSN, caps planned rows at `20`, and defaults every row review item to
`needs_manual_review`. The readiness verdict is
`Ready only after planned-row manual review`. See
[`stage-18j-p12-p13-load-plan-review-packet.md`](./stage-18j-p12-p13-load-plan-review-packet.md).

Stage 18J-P13A fixes the P12/P13 review packet contract after the first
offline Hetzner packet proved safe but not human-reviewable enough. Each
`manual_review_items` entry now embeds the full planned row, boolean review
checks, and `reviewer_notes = null`, while the top-level `planned_rows` list
remains for convenience and must match the embedded rows exactly. The wrapper
prints and validates these contract fields before declaring the packet
generated.

Stage 18J-P14 adds controlled external identity load tooling in
`apps/importer/src/station_external_identity_loader.py` and a dry-run-only
Hetzner wrapper in `scripts/operator/archive/stage18j/stage18j_run_identity_load_dry_run.sh`.
The loader validates verified review packets and emits
`station_external_identity_load_execution_plan/v1`; write mode requires a
separate `station_external_identity_load_approval_allowlist/v1` artifact plus
explicit confirmation flags. This PR keeps production identity writes blocked
and does not add a production write operator script. See
[`stage-18j-p14-controlled-external-identity-load-tooling.md`](./stage-18j-p14-controlled-external-identity-load-tooling.md).

Stage 18J-P14B reviews the first controlled identity load dry-run. The
execution plan selected `20` review items and `20` plan rows from
`station_external_identity_review_packet_20260603T110848Z.json`, verified
review packet SHA-256
`8cf118d552e6bc35d23ab302d9e1020092385b372729dbb9b2bae5cd5f0758b6`, kept
`canonical_writes_planned = 0`, `station_type_writes_planned = 0`, and
`identity_rows_written = 0`, and left `station_external_identity` at `0` rows.
The verdict is `Ready only after approval allowlist artifact`. See
[`stage-18j-p14b-identity-load-dry-run-review.md`](./stage-18j-p14b-identity-load-dry-run-review.md).

Stage 18J-P14C adds the offline approval allowlist artifact generator in
`apps/importer/src/station_external_identity_approval_allowlist.py` and a
Hetzner-only wrapper in
`scripts/operator/archive/stage18j/stage18j_run_identity_approval_allowlist.sh`. The allowlist
approves exact external identity evidence rows only; it is not station-type
approval, canonical apply approval, or a production approval record. See
[`stage-18j-p14c-approval-allowlist-artifact.md`](./stage-18j-p14c-approval-allowlist-artifact.md).

Stage 19A defines the warehouse artifact taxonomy and chunked roadmap before
the warehouse broadens beyond the station reconciliation path. It separates
stations, bodies, rings, station/body links, markets, services, economies,
colonisation, freshness, coverage, analytics, and future write-plan artifacts;
standardizes domain-qualified names; and requires source inventory, load,
reconciliation, compact summary, dry-run, approval packet, and manual apply to
remain separate chunks. Scheduler work remains design-only and disabled by
default; scheduled jobs must never run canonical apply. See
[`stage-19a-warehouse-artifact-taxonomy-and-chunked-roadmap.md`](./stage-19a-warehouse-artifact-taxonomy-and-chunked-roadmap.md).

Stage 19A.1 adds operator path guardrails after Codex/local and Hetzner command
contexts were repeatedly confused. It adds a reusable Hetzner environment guard,
a Stage 18J compact-summary operator wrapper, and
`docs/operations/operator-command-contexts.md`. Codex remains for repo/code/docs
and PR work; `/opt/ed-finder`, `/var/lib/ed-finder`, Docker Compose production
services, production Postgres containers, and production artifacts belong in
the Hetzner operator shell. The scripts are tooling/docs only and do not start
Stage 18J-P, Stage 18K, scheduler wiring, or canonical apply.

The operator workflow and current command examples live in
[`../operations/enrichment-warehouse-runbook.md`](../operations/enrichment-warehouse-runbook.md).
Use that runbook before loading any local snapshot into staging tables.

This is the long-term replacement direction for large live API crawls: load
repeatable offline snapshots into raw/staging evidence, compare read-only
against canonical ED-Finder tables, produce pure versioned dry-run plans, and
keep warehouse output report-only unless a separate canonical write design is
approved later.

---

## 9. Roadmap

The list below is intentionally narrow — anything not on it should be
treated as a separate proposal.

* **Status integration hardening**: keep the station and warehouse Admin tab
  status artifacts mounted from operator-managed paths, and add deployment
  alerts around missing or stale artifacts if production operations need them.
* **Sticky failed-system retry queue**: today, fetch-failed systems naturally
  re-enter the next batch because they have no trusted provenance yet. If
  that becomes too slow for very large outages, materialise a separate
  retry queue (with its own backoff schedule) instead of pulling them in
  via the regular eligible-station SQL.
* **PostgreSQL-backed checkpoint**: the JSON file is fine for one-host ops.
  When we move to multi-host nightly enrichment we should put the
  checkpoint in Postgres (`enrichment_progress` table) so multiple workers
  can coordinate without stepping on each other.
* **Optional `--retry-failed` mode**: a second top-level mode that only
  re-runs the systems that appeared in any historical `systems_fetch_failed`
  list, with a tighter rate-limit profile.
* **Ring enrichment guarded mode**: parity wrapper for the Spansh-first ring
  enrichment, sharing the same checkpoint discipline.
* **Warehouse reconciliation hardening**: broaden read-only reconciliation
  quality checks across staged station, body, and ring evidence while
  preserving `distanceToArrival` as volatile evidence instead of a churn
  source.
* **Warehouse artifact taxonomy**: Stage 19A fixes the naming and chunking
  contract before broader warehouse domains are added. Keep load,
  reconciliation, compact summary, dry-run, approval, and apply artifacts
  separate.
* **Operator path guardrails**: Stage 19A.1 keeps Codex/local work separate
  from Hetzner operator commands and adds fail-fast guards for server-only
  scripts.
* **Station-type dry-run readiness**: Stage 18J-Q9 allows only a filtered
  station-type dry-run readiness path. Do not run Stage 18J-P against the full
  station reconciliation candidate set.
* **Strict station-type filter hardening**: Stage 18J-P-filter implements the
  strict filter and synthetic tests. A future Stage 18J-P production dry-run
  can proceed only as a separate operator step after this hardening merges.
* **Operator-safe station-type dry-run wrapper**: Stage 18J-P-dryrun-ops adds
  the Hetzner-only wrapper, checksum guard, max-row cap, and compact blocked
  output required before the future production dry-run operator step.
* **External station identity schema**: Stage 18J-P3/P4 confirm the blocker and
  design a separate provenance-backed `station_external_identity` table. Do not
  relax the strict station-type filter or reuse `stations.id` as external
  proof.
* **External identity migration draft**: Stage 18J-P5 adds
  `sql/027_station_external_identity.sql` and migration contract tests. This is
  a draft only; production application requires a later readiness review.
* **External identity migration readiness**: Stage 18J-P6 reviews migration 027
  and finds it ready for a later schema-only production application stage with
  explicit preflight and post-apply checks.
* **External identity schema closeout**: Stage 18J-P7 records that migration
  027 has been applied on Hetzner as schema-only. The identity table exists but
  is empty, so strict station-type dry-run remains blocked.
* **External identity loader design**: Stage 18J-P8 requires a read-only
  identity candidate artifact from staged EDSM station evidence before any
  writes to `station_external_identity`.
* **External identity candidate artifact**: Stage 18J-P9 implements the
  read-only candidate artifact generator. It proposes reviewable identities but
  writes nothing to `station_external_identity`.
* **External identity artifact review**: Stage 18J-P10 reviews the first
  Hetzner candidate artifact and finds it ready only for a bounded no-write
  identity load-plan dry-run.
* **External identity bounded load-plan**: Stage 18J-P11 implements the
  no-write load-plan artifact. It proposes at most an explicit bounded set of
  identity rows for review and still writes nothing to
  `station_external_identity`.
* **External identity execution board**: Stage 18J-P-OPT groups remaining
  repo work into larger safe chunks while keeping Hetzner production actions
  tiny and single-purpose.
* **External identity planned-row review packet**: Stage 18J-P12/P13 records
  the bounded load-plan review and adds an offline packet generator for manual
  review of the `20` planned rows. It writes no identity rows and keeps
  station-type dry-run and canonical apply blocked.
* **External identity review packet contract hardening**: Stage 18J-P13A makes
  manual review items self-contained with embedded planned rows and boolean
  checks, then requires a future offline packet rerun before planned rows can
  be reviewed.
* **External identity controlled load tooling**: Stage 18J-P14 adds load
  validation and dry-run execution plan tooling, plus approval allowlist support
  for later write-reviewed runs. Production identity writes remain blocked in
  this PR.
* **External identity load dry-run review**: Stage 18J-P14B records the safe
  load dry-run result and sets the verdict to `Ready only after approval
  allowlist artifact`. The selected rows are structurally loadable but not yet
  approved for insertion.
* **External identity approval allowlist artifact**: Stage 18J-P14C adds the
  offline allowlist generator and Hetzner-only wrapper for exact selected
  review item IDs and plan row IDs. It approves external identity evidence load
  scope only and still loads no rows.
* **External identity follow-up sequence**: use the execution board for Chunk A
  P12/P13 review pack, Chunk B P14/P14B controlled identity load tooling and
  dry-run review, P14C approval allowlist, P14D controlled write-reviewed load,
  Chunk C P15 post-load identity coverage, Chunk D P16 read-only reconciliation
  integration, and Chunk E P17 strict station-type dry-run retry.
* **Warehouse expansion and freshness design**: after the Stage 18J-Q6 station
  staging retry, read-only artifact path, compact reconciliation review, and
  Stage 19A/19A.1 guardrails are boring, Stage 19 should broaden warehouse
  source coverage and design freshness/scheduler support. Scheduler or cron
  implementation is not part of Q6/Q8/19A/19A.1.
* **Report-only analytics maturation**: improve confidence/risk explanations,
  source coverage summaries, colonisation signals, and mission-density signals
  without writing canonical data.
* **Optional smoke coverage**: keep real-Postgres smoke tests skipped by
  default and focused on staging tables plus read-only reports.

---

## 10. Suggested local test commands

These all run offline; they never touch EDSM or the production database.

```sh
# Importer probe (distance trust-and-hold, 429 floor, identity gating, …)
python3 -m pytest tests/test_edsm_station_enrichment_probe.py -q

# Guard wrapper (checkpoint, no-op skip, success-only checkpointing, …)
python3 -m pytest tests/test_station_enrichment_guard.py -q

# Status helper
python3 -m pytest tests/test_station_enrichment_status.py -q

# All three together
python3 -m pytest \
    tests/test_edsm_station_enrichment_probe.py \
    tests/test_station_enrichment_guard.py \
    tests/test_station_enrichment_status.py -q
```
